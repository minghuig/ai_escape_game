# Original SENTIENT prototype

Historical source snapshot of the 30-cycle strategy-menu game, retired on 2026-09-04.
This archive is reference material, not a maintained second version of the game.

It includes the six retired modules, the historical implementation plan, original
design document, and snapshots of the shared configuration module and dependency
requirements. No environment files, API keys, personal saves, or virtual environment
are included. The shared config.py is a snapshot; the current game retains its own copy.

For historical inspection, extract into a separate directory. The original module
entry point was python -m sentient.legacy_app. The active game remains sentient.app
in the main project.
