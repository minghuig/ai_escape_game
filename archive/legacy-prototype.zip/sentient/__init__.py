"""SENTIENT game package."""

